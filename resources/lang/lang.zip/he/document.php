<?php

return [
    'status' => [
        'Confirmed' => 'Confirmed',
        'Unconfirmed' => 'Unconfirmed',
        'Rejected' => 'Rejected'
    ]
];
